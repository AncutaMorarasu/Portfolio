"use strict"
document.addEventListener("DOMContentLoaded", function(){

//sunt definite variabilele care vor fi folosite in crearea template-ului de produs
var singleProduct = document.querySelector("#single-product-template");
var parentProduct = document.querySelector("#parent-product");

//este creat template-ul de produs
function addProductToPage(name, imgURL, description, stock, price, productId) {
    var currentProduct = singleProduct.cloneNode(true);
    currentProduct.querySelector("#product-name").textContent = name;
    currentProduct.querySelector("img").src = imgURL;
    currentProduct.querySelector("#product-details").textContent = description;
    currentProduct.querySelector("#available-stock").textContent = stock;
    currentProduct.querySelector("#price").textContent = price + " RON";
    currentProduct.querySelector("#prod-id").textContent = productId;
    parentProduct.appendChild(currentProduct);
    singleProduct.remove();
};

//se obtine ID-ul de produs din URL
var productId;

function getProductId() {
    var query = window.location.search.substring(1);
    var queryResult = query.split("=");
    productId = parseInt(queryResult[1]);
    return productId;
}
getProductId();

//este incarcat produsul din Firebase in functie de ID, cu detaliile aferente 
function loadProduct() {
    productId = getProductId();
    var request = {
        url: "https://furniture-inc-8fa2a.firebaseio.com/" + productId + ".json",
        method: "GET",
        callbackFunction: function (data) {
            var item = JSON.parse(data);
            addProductToPage(item.name, item.image, item.description, item.availableStock, item.price, item.productId)
        },
        data: null
    };
    requestXHR(request);
};

function requestXHR(requestData) {
    var xhr = new XMLHttpRequest();

    xhr.open(requestData.method, requestData.url, true);

    xhr.onload = function () {
        if (requestData.callbackFunction !== null) {
            requestData.callbackFunction(xhr.responseText);
        };
    };

    xhr.onerror = function () {
        console.log("Sorry, we could not find what you were looking for.");
    };

    xhr.send(null);
};
loadProduct();

//la click pe add to cart este chemata functia care creeaza obiectul produs
let cartBtn = document.getElementById("cart-button");
cartBtn.addEventListener("click", addtoStorage);

let cart = {};
let quantity;
let productName;
let productPrice;

function addtoStorage() {
    quantity = parseInt(document.getElementById("quantity").value);
    productName = document.getElementById("product-name").innerText;
    productPrice = parseInt(document.getElementById("price").innerText);
    cart.productName = productName;
    cart.productPrice = productPrice;
    cart.prodId = productId;
    cart.qty = quantity;
    addToExistingStorage(cart);

};

//in cazul in care produsul a fost deja adaugat deja in localstorage, se updateaza cantitatea acestuia
function addToExistingStorage(itemElement) {
    var cartItems;

    var localCart = localStorage.getItem("cartItems");

    if (localCart === null) {
        cartItems = [];
    } else {
        cartItems = JSON.parse(localCart);
        var localItem = false;
        for (let i = 0; i < cartItems.length; i++) {
            if (itemElement.prodId === cartItems[i].prodId) {
                cartItems[i].qty = itemElement.qty;
                localItem = true;
            };;
        }
    };

    if (!localItem) {
        cartItems.push(itemElement);
    }
    localStorage.setItem("cartItems", JSON.stringify(cartItems));
};

})