"use strict" 

document.addEventListener("DOMContentLoaded", function(){
    //este definit produsul nou
    let newProduct;

    let addBtn = document.querySelector("#add-product");

    addBtn.addEventListener("click", function(){
        //produsul va avea proprietati identice cu cele ale produselor deja existente in Firebase
         newProduct = {
            name: document.querySelector("#add-name").value,
            productId: parseInt(document.querySelector("#add-id").value),
            image: document.querySelector("#add-photo-url").value,
            description: document.querySelector("#add-description").value,
            availableStock: parseInt(document.querySelector("#add-stock").value),
            price: parseInt(document.querySelector("#add-price").value),
            productEnabled: document.querySelector('input[name="product-status"]:checked').value
        }
        //se trimite noul produs prin verbul PUT in baza de date
        function sendProduct () {
            var xhr = new XMLHttpRequest;
            var url = 'https://furniture-inc-8fa2a.firebaseio.com/' + newProduct.productId + '.json';
            xhr.open("PUT", url, true); 
            xhr.setRequestHeader("Content-Type", "application/json");
            var sendData = JSON.stringify(newProduct);
            xhr.send(sendData);
            console.log(sendData);
        }
        
        //este chemata functia care trimite datele noului produs in baza de date
        sendProduct();
        //este chemata functia care afiseaza notificarea de adaugare a produsului
        addConfirmationFct();
        
   });
   //la click pe buton sunt sterse valorile din inputuri pentru a lasa utilizatorul sa adauge inca un produs daca doreste
   let clearBtn = document.getElementById('clear-inputs');
   clearBtn.addEventListener("click", function(){
       document.getElementById("add-name").value = "";
       document.querySelector("#add-id").value = "";
       document.getElementById("add-photo-url").value = "";
       document.getElementById("add-description").value = "";
       document.getElementById("add-stock").value = "";
       document.getElementById("add-price").value = "";
       document.querySelector('input[name="product-status"]:checked').value = "";
   });

   //se afiseaza notificarea de adaugare a produsului timp de 3 secunde
   function addConfirmationFct() {
    let addConfirmation = document.querySelector('#add-confirmation');
    addConfirmation.style.display = "block";
    let interval = setInterval(removeNotification, 3000);
    //notificarea este inlaturata
    function removeNotification() {
        addConfirmation.style.display = "none";
        clearInterval(interval);
    };

};
});

