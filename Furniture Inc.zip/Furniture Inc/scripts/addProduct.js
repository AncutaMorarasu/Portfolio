"use strict"

document.addEventListener("DOMContentLoaded", function () {
    
    //la click pe butonul de adaugare este chemata functia checkInputs()
    let addBtn = document.querySelector("#add-product");
    addBtn.addEventListener("click", function () {
        checkInputs();
    });

    //se trimite noul produs prin verbul PUT in baza de date
    function sendProduct() {
        // produsul nou care va avea proprietati identice cu cele ale produselor deja existente in Firebase
        let newProduct = {
            name: document.querySelector("#add-name").value,
            productId: parseInt(document.querySelector("#add-id").value),
            image: document.querySelector("#add-photo-url").value,
            description: document.querySelector("#add-description").value,
            availableStock: parseInt(document.querySelector("#add-stock").value),
            price: parseInt(document.querySelector("#add-price").value),
            productStatus: document.querySelector('input[name="product-status"]:checked').value
        };
        let xhr = new XMLHttpRequest;
        let url = 'https://furniture-inc-8fa2a.firebaseio.com/' + newProduct.productId + '.json';
        xhr.open("PUT", url, true);
        xhr.setRequestHeader("Content-Type", "application/json");
        let sendData = JSON.stringify(newProduct);
        xhr.send(sendData);
    }
    //la click pe butonul Clear sunt sterse valorile din inputuri pentru a lasa utilizatorul sa adauge inca un produs daca doreste
    let clearBtn = document.getElementById('clear-inputs');
    clearBtn.addEventListener("click", function () {
        document.getElementById("add-name").value = "";
        document.querySelector("#add-id").value = "";
        document.getElementById("add-photo-url").value = "";
        document.getElementById("add-description").value = "";
        document.getElementById("add-stock").value = "";
        document.getElementById("add-price").value = "";
        document.querySelector('input[name="product-status"]:checked').value = "";
    });

    //se afiseaza notificarea de adaugare a produsului timp de 3 secunde
    function addConfirmationFct() {
        let addConfirmation = document.querySelector('#add-confirmation');
        addConfirmation.style.display = "block";
        let interval = setInterval(removeNotification, 3000);
        //notificarea este inlaturata
        function removeNotification() {
            addConfirmation.style.display = "none";
            clearInterval(interval);
        };

    };

    //verifica daca toate inputurile au fost completate, daca da, produsul este trimis in vaza de date, daca nu, o notificare este afisata in acest sens
    function checkInputs() {
        let addName = document.querySelector("#add-name").value;
        let addId = parseInt(document.querySelector("#add-id").value);
        let addImg = document.querySelector("#add-photo-url").value;
        let addDescription = document.querySelector("#add-description").value;
        let addStock = parseInt(document.querySelector("#add-stock").value);
        let addPrice = parseInt(document.querySelector("#add-price").value);
        let addStatus = document.querySelector('input[name = "product-status"]:checked')
        if (addName === "") {
            displayError();
            return;
        }
        if (addId === NaN) {
            displayError();
            return;
        }
        if (addImg === "") {
            displayError();
            return;
        }
        if (addDescription === "") {
            displayError();
            return;
        }
        if (addStock === NaN) {
            displayError();
            return;
        }
        if (addPrice === NaN) {
            displayError();
            return;
        } 
        if (addStatus === null) {
            displayError();
            return;
        } else {
            sendProduct();
            addConfirmationFct();
            setTimeout(function () {
                window.location.href = 'admin.html';
            }, 3000);
        }
    }
   
});
