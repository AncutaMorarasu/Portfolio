"use strict"

document.addEventListener("DOMContentLoaded", function () {
    //este definit formularul de produs de editat
    let currentEdit = document.querySelector("#product-real");
    //sunt asociate detaliile de produs cu fieldurile in care vor fi afisate 
    function addProdtoEdit(name, image, description, availableStock, price, productId) {
        currentEdit.querySelector("#product-name").textContent = name;
        currentEdit.querySelector("#srcPhoto").src = image;
        currentEdit.querySelector("#product-description").textContent = description;
        currentEdit.querySelector("#product-stock").textContent = availableStock;
        currentEdit.querySelector("#product-price").textContent = price;
        currentEdit.querySelector("#prod-id").textContent = productId;

        /*sunt afisate in textinput valorile deja existente in baza de date pentru a usura experienta utilizatorului
         in cazul in care doreste sa aduca doar modificari minore produsului */
        currentEdit.querySelector("#new-name").value = currentEdit.querySelector("#product-name").textContent;
        currentEdit.querySelector("#new-photo").value = currentEdit.querySelector("#srcPhoto").src;
        currentEdit.querySelector("#new-description").value = currentEdit.querySelector("#product-description").textContent;
        currentEdit.querySelector("#new-stock").value = currentEdit.querySelector("#product-stock").textContent;
        currentEdit.querySelector("#new-price").value = currentEdit.querySelector("#product-price").textContent;
    }


    let saveBtn = document.getElementById('save-changes');
    saveBtn.addEventListener("click", function () {
        checkInputsSubmit();
    });


    //confirmarea de editare este afisata la click pe buton 
    function editConfirmationFct() {
        let deleteConfirmation = document.getElementById("edit-confirmation");
        deleteConfirmation.classList.remove('hidden');
        let interval = setInterval(removeNotification, 3000);

        function removeNotification() {
            deleteConfirmation.classList.add('hidden');
            clearInterval(interval);
        };

    };

    //este incarcat produsul de editat din Firebase in functie de ID, cu detaliile aferente 
    function loadProductToEdit() {
        productId = getProductId();
        let request = {
            url: "https://furniture-inc-8fa2a.firebaseio.com/" + productId + ".json",
            method: "GET",
            callbackFunction: function (data) {
                let item = JSON.parse(data);
                if (item === null) {
                    productError();
                } else {
                    addProdtoEdit(item.name, item.image, item.description, item.availableStock, item.price, item.productId)
                }
            },
            data: null
        };
        requestXHR(request);
    };
    loadProductToEdit();

    //daca a fost introdus un ID de produs invalid, div-ul care contine template-ul de produs este inlocuit cu un mesaj de eroare
    function productError() {
        let contentDiv = document.querySelector("#product-template");
        contentDiv.innerText = "This product is unavailable. Please check the URL and try again.";
    }


    // se trimite produsul editat in Firebase cu verbul PATCH
    function requestXhrPatch() {
        let editedProduct = {
            name: document.getElementById("new-name").value,
            image: document.getElementById("new-photo").value,
            description: document.getElementById("new-description").value,
            availableStock: document.getElementById("new-stock").value,
            price: document.getElementById("new-price").value,
            productStatus: document.querySelector('input[name="product-status"]:checked').value
        };
        let postXHR = new XMLHttpRequest();
        let url = "https://furniture-inc-8fa2a.firebaseio.com/" + productId + ".json";
        postXHR.open("PATCH", url, true);
        postXHR.setRequestHeader("Content-Type", "application/json");
        postXHR.send(JSON.stringify(editedProduct));
    };

    //la click pe butonul de stergere, este chemata functia deleteProductFromDB
    let deleteBtn = document.querySelector('#delete-product');
    deleteBtn.addEventListener('click', deleteProductFromDB);

    //stergere produs din Firebase in functie de ID produs
    function deleteProductFromDB() {
        var deleteXHR = new XMLHttpRequest();
        deleteXHR.open("DELETE", "https://furniture-inc-8fa2a.firebaseio.com/" + productId + ".json", true);
        deleteXHR.send(null);
        //notificare stergere produs
        deleteConfirmationFct();
        //dupa 3 secunde de afisare a notificafii, utilizatorul este trimis pe pagina principala de admin
        setTimeout(function () {
            window.location.href = 'admin.html';
        }, 3000);

    }
    //functie care afiseaza o notificare pe ecran la stergerea produsului, si o inlatura dupa 3 secunde
    function deleteConfirmationFct() {
        let deleteConfirmation = document.querySelector('#delete-confirmation');
        deleteConfirmation.classList.remove('hidden');
        let interval = setInterval(removeNotification, 3000);
        //notificarea este inlaturata
        function removeNotification() {
            deleteConfirmation.classList.add('hidden');
            clearInterval(interval);
        };
    }

    /*functia verifica toate inputurile din formularul de editare produs, 
    in cazul in care nu sunt valide, o notificare este afisata si functia de opreste
    Altfel, produsul editat este trimis in Firebase, si o confirmare de stergere este afisata  */
    function checkInputsSubmit() {
        let newName = document.querySelector("#new-name").value;
        let newImg = document.querySelector("#new-photo").value;
        let newDescription = document.querySelector("#new-description").value;
        let newStock = parseInt(document.querySelector("#new-stock").value);
        let newPrice = parseInt(document.querySelector("#new-price").value);
        let newStatus = document.querySelector('input[name = "product-status"]:checked')
        if (newName === "") {
            displayError();
            return;
        }
        if (newImg === "") {
            displayError();
            return;
        }
        if (newDescription === "") {
            displayError();
            return;
        }
        if (newStock === NaN) {
            displayError();
            return;
        }
        if (newPrice === NaN) {
            displayError();
            return;
        }
        if (newStatus === null) {
            displayError();
            return;
        } else {

            requestXhrPatch();

            editConfirmationFct();
            //dupa 3 secunde de afisare a notificafii, utilizatorul este trimis pe pagina principala de admin
            setTimeout(function () {
                window.location.href = 'admin.html';
            }, 3000);
        }
    }

});