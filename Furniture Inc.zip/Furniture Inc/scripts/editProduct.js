"use strict"

document.addEventListener("DOMContentLoaded", function () {
    //sunt definite variabilele care vor fi folosite in crearea template-ului de produs editat

    var editedProduct;

    var singleProduct = document.querySelector("#product-real");
    var parentProduct = document.querySelector("#product-template");
    var currentEdit = singleProduct.cloneNode(true);
    //este creat template-ul de produs editat
    function addProdtoEdit(name, image, description, availableStock, price, productId) {
        currentEdit.querySelector("#product-name").textContent = name;
        currentEdit.querySelector("#srcPhoto").src = image;
        currentEdit.querySelector("#product-description").textContent = description;
        currentEdit.querySelector("#product-stock").textContent = availableStock;
        currentEdit.querySelector("#product-price").textContent = price;
        currentEdit.querySelector("#prod-id").textContent = productId;
        parentProduct.appendChild(currentEdit);
        singleProduct.remove();

        /*sunt afisate in textinput valorile deja existente in baza de date pentru a usura experienta utilizatorului in cazul in care doreste 
        sa aduca doar modificari minore  produsului */

        currentEdit.querySelector("#new-name").value = currentEdit.querySelector("#product-name").textContent;
        currentEdit.querySelector("#new-photo").value = currentEdit.querySelector("#srcPhoto").src;
        currentEdit.querySelector("#new-description").value = currentEdit.querySelector("#product-description").textContent;
        currentEdit.querySelector("#new-stock").value = currentEdit.querySelector("#product-stock").textContent;
        currentEdit.querySelector("#new-price").value = currentEdit.querySelector("#product-price").textContent;

        let saveBtn = document.getElementById('save-changes');
        saveBtn.addEventListener("click", function () {
            editedProduct = {
                name: document.getElementById("new-name").value,
                image: document.getElementById("new-photo").value,
                description: document.getElementById("new-description").value,
                availableStock: document.getElementById("new-stock").value,
                price: document.getElementById("new-price").value,
                productStatus: document.querySelector('input[name="product-status"]:checked').value
            };

            requestXhrPatch();

            editConfirmationFct();
            //dupa 3 secunde de afisare a notificafii, utilizatorul este trimis pe pagina principala de admin
            setTimeout(function () {
                window.location.href = 'admin.html';
            }, 2000);

        });
    };

    //confirmarea de editare este afisata la click pe buton 
    function editConfirmationFct() {
        let deleteConfirmation = document.getElementById("edit-confirmation");
        deleteConfirmation.style.display = "block";
        let interval = setInterval(removeNotification, 3000);

        function removeNotification() {
            deleteConfirmation.style.display = "none";
            clearInterval(interval);
        };

    };

    //se obtine ID-ul de produs din URL
    let productId;

    function getProductId() {
        var query = window.location.search.substring(1);
        var queryResult = query.split("=");
        productId = parseInt(queryResult[1]);
        return productId;
    };



    //este incarcat produsul de editat din Firebase in functie de ID, cu detaliile aferente 
    function loadProductToEdit() {
        productId = getProductId();
        var request = {
            url: "https://furniture-inc-8fa2a.firebaseio.com/" + productId + ".json",
            method: "GET",
            callbackFunction: function (data) {
                var item = JSON.parse(data);
                addProdtoEdit(item.name, item.image, item.description, item.availableStock, item.price, item.productId)

            },
            data: null
        };
        requestXHR(request);
    };

    function requestXHR(requestData) {
        var xhr = new XMLHttpRequest();
        xhr.open(requestData.method, requestData.url, true);
        xhr.onload = function () {
            if (requestData.callbackFunction !== null) {
                requestData.callbackFunction(xhr.responseText);
            };
        };
        xhr.onerror = function () {
            console.log("Sorry, we could not find what you were looking for.");
        };
        xhr.send(null);
    };

    loadProductToEdit();

    // se trimite produsul editat in Firebase cu verbul PATCH
    function requestXhrPatch() {
        var postXHR = new XMLHttpRequest();
        var url = "https://furniture-inc-8fa2a.firebaseio.com/" + productId + ".json";
        postXHR.open("PATCH", url, true);
        postXHR.setRequestHeader("Content-Type", "application/json");
        postXHR.send(JSON.stringify(editedProduct));
    };

});